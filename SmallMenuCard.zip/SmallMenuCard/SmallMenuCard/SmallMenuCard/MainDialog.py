from botbuilder.dialogs import (
    ComponentDialog,
    WaterfallDialog,
    DialogTurnResult,
    WaterfallStepContext
)
from botbuilder.dialogs.prompts import TextPrompt, PromptOptions
from botbuilder.core import MessageFactory

from botbuilder.dialogs import ComponentDialog
class MainDialog(ComponentDialog):
    def __init__(self, configuration: dict, dialog_id: str = None):
        super(MainDialog, self).__init__(dialog_id or MainDialog.__name__)
        self.configuration = configuration


        self.add_dialog(
            WaterfallDialog(
                WaterfallDialog.__name__,
                steps=[
                    self.inputoperator,
                    self.result
                ]
                )
            )
        self.add_dialog(TextPrompt(TextPrompt.__name__))
        self.initial_dialog_id = WaterfallDialog.__name__

    
    async def reviewInput(self,step_context:WaterfallStepContext) -> DialogTurnResult:
        RPA=step_context.result
        step_context.options["RPA"]=RPA

        Automation=step_context.options["Automation"]
        await step_context.context.send_activity(f"RPA:  {RPA} Automation: {Automation} ")
        #return await step_context.end_dialog()

    async def inputoperator(self,step_context:WaterfallStepContext) -> DialogTurnResult:
        Automation=step_context.result
        step_context.options["Automation"]="Automation"
        return await step_context.prompt(
            TextPrompt.__name__,
            PromptOptions(prompt=MessageFactory.text("Please Select ypur Choice [RPA /Automation]. ")),
        )

    async def result(self,step_context:WaterfallStepContext) -> DialogTurnResult:
        
        op=step_context.result
        step_context.options["op"]=op
        
        if op == "RPA":
            res="Robotic Process Automation..."
        elif op=="Automation":
            res="Automation makes jobs safer and does ones that are unsafe for people, like smelting metal"
        else:
            res="Invalid Operation"
        await step_context.context.send_activity(f"Result: {res} ")
        #return await step_context.end_dialog()
        return await step_context.replace_dialog(self.initial_dialog_id, step_context.options)









